# ICARUS Unified World Phase 1 Lite

Minimal runtime distribution from the exact source commit c73c7da49e19fe82b2fb8028cbd6fc30915d2864 in thekiddam-code/munza69. All retained application files are unchanged. Lite removes standalone tests, reports, developer utilities, packaging scripts and historical documents; it does not redesign or complete the original Phase 1 feature set.

## Run on the host PC

1. Extract the entire folder to a permanent, writable location. Keep `server.py`, `config.json`, `requirements.txt`, the BAT launcher and the complete `web` folder together.
2. Install Python and the declared runtime packages if needed: open a terminal in this folder and run `py -m pip install -r requirements.txt` (or `python -m pip install -r requirements.txt`). This is a source runtime distribution, not a standalone EXE or an offline bundle of Python packages.
3. On Windows, run `Start_Remote_Deck.bat`. Keep its console open. On another supported desktop environment you can run `python server.py`; PyAutoGUI requires a usable desktop/display.
4. Open the printed ICARUS PC URL, normally `http://127.0.0.1:8765/icarus.html`. Connect its bridge using the PC-only host key printed in the console. Never enter the PC host key on an untrusted phone.

The default production clock is 4× real time; nine synchronized local holidays use 1×. Choose the IANA timezone in Settings. Episodes follow real local Monday–Sunday weeks. Ordinary pause is a session control, as in the pinned source; startup begins unpaused. Offline catch-up is limited to six real hours, with older gaps logged.

## Connect Android / Remote Deck

Use a browser on the same trusted local network as the PC. Open the **Phone URL printed by the server**, for example `http://192.168.1.20:8765/`—not the PC's 127.0.0.1 address. Enter the printed pairing PIN. Keep the PC simulation tab and host server running. The phone is a controller/observer; it does not run a second simulation. Re-pair or enter the new PC host key after a server restart where required. Device pairing persists through the host's generated token-hash file; Forget this phone revokes it.

UMBRA desktop/game controls, system monitoring and optional Samsung TV control are preserved. They can intentionally affect the host computer or configured TV; read SECURITY_REVIEW.md before using them. A network/device problem is not a reason to disable antivirus. No firewall, registry or antivirus changes are automated by this package.

## Preserve an existing voyage

Export a complete JSON backup from the current PC simulation before switching folders. Browser saves belong to the browser profile and origin (scheme, hostname and port), not the extracted folder. Reuse the same PC browser profile and exact origin/port to retain IndexedDB saves; `localhost` and `127.0.0.1` are different origins. Import your JSON backup through Settings if moving profiles/origins. Export contains history and calendar/unified state; Android stores its own controller token, not the authoritative crew/world save.

If replacing an existing host folder, preserve your customized `config.json` and generated `paired_devices.json` / `samsung_tv.json` privately. Those user-specific generated files are deliberately not distributed. No private voyage, paired token, host key or TV token is shipped in this package.

## What Lite retains

All Phase 1 code at the pinned commit: autonomous crew/ship operations, science/Lazarus, finite resources and repair rules, 4×/holiday calendar, real-week recaps, spatial camera support, creator/acquired lore, persistent personal objects, military/host-development foundations, captain controls, Remote Deck and save/backup mechanisms. All loaded JavaScript, HTML, manifest and vendored LZ-String/license assets are kept, including loaded diagnostic helpers needed for exact source fidelity. Python dependency declarations are unchanged.

Lite inherits the source's unfinished areas: full creature AI/ecology, final character/prop art and animation, exact lunar ephemerides, richer personal observances, complete radio/individual-knowledge and spatial-view consolidation, and wider device/human review. Lite means a smaller distribution, not a newly completed overhaul.

The SHA-256 file and detailed verification report are provided beside the ZIP on the downloads/unified-phase1-lite GitHub branch. Test suites, raw test reports and packaging tools are not inside this runtime ZIP. RUNTIME_MANIFEST.json records every retained runtime file's source hash. SECURITY_REVIEW.md documents intentional remote-control behavior and inherited security limitations.

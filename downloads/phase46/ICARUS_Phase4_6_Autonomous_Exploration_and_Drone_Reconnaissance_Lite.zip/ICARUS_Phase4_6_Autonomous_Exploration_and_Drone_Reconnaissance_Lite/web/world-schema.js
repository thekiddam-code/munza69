/* Nonmutating structural checks. Optional old domains remain migratable. */
(function(root){'use strict';
const object=x=>!!x&&typeof x==='object'&&!Array.isArray(x),array=Array.isArray,finiteMap=x=>object(x)&&Object.values(x).every(n=>Number.isFinite(n)&&n>=-1e-7);
function valid(s,requireModern=false,requireAnthology=false,requireUnified=false){
 if(!object(s)||!array(s.crew)||!Number.isFinite(s.tick)||s.tick<0||!Number.isInteger(s.episode)||s.episode<1)return false;
 for(const p of s.crew){
  if(p.visualAppearance!==undefined&&(!root.ICARUSCharacterDesign||!root.ICARUSCharacterDesign.valid(p.visualAppearance)))return false;
  for(const key of ['roomPlacement','roomInteraction']){const x=p[key];if(x===undefined)continue;if(!object(x)||!/^([ABC])(0[1-9]|10)$/.test(x.room)||!Number.isFinite(x.x)||x.x<0||x.x>384||!Number.isFinite(x.y)||x.y<120||x.y>216)return false;
   if(key==='roomInteraction'&&(x.version!==1||!['approaching','turning','seating','working','rising'].includes(x.phase)||!Number.isFinite(x.lastTick)||x.lastTick>s.tick||![-1,1].includes(x.facing)||typeof x.signature!=='string'||x.signature.length>500||typeof x.task!=='string'||typeof x.fixture!=='string'))return false;
  }
 }
 if(root.ICARUSDroneSchema&&!root.ICARUSDroneSchema.valid(s))return false;
 if(root.ICARUSExpeditionSchema&&!root.ICARUSExpeditionSchema.valid(s))return false;
 if(requireAnthology&&s.anthology===undefined)return false;
 if(requireUnified&&!s.unifiedWorld)return false;
 if(s.solVoice!==undefined){const v=s.solVoice;if(!object(v)||v.version!==1||!array(v.entries)||v.entries.length>48||!array(v.seen)||v.seen.length>192||!object(v.signatures)||!Number.isFinite(v.lastAt)||!Number.isInteger(v.nextId))return false;}
 if(s.cinema!==undefined){const c=s.cinema;if(!object(c)||c.version!==1||!array(c.recordings)||c.recordings.length>120||(c.sourceFrames!==undefined&&(!array(c.sourceFrames)||c.sourceFrames.length>24))||!object(c.films)||Object.keys(c.films).length>12||Object.values(c.films).some(f=>!object(f)||!array(f.segments)||f.segments.length>35||!Number.isFinite(f.duration))||!Number.isInteger(c.nextRecording)||!Number.isFinite(c.lastCapture))return false;for(const r of [...c.recordings,...(c.sourceFrames||[])])if(!object(r)||!array(r.actors)||!array(r.sourceIds)||typeof r.room!=='string'||typeof r.label!=='string'||r.actors.some(p=>!object(p)||typeof p.name!=='string'||p.room!==r.room||p.node!=='R:'+r.room)||!Number.isFinite(r.at)||r.at>s.tick)return false;}
 if(s.crewLife!==undefined){const c=s.crewLife;if(!object(c)||c.version!==1||!object(c.people)||!Number.isInteger(c.conversations)||c.conversations<0)return false;for(const p of Object.values(c.people))if(!object(p)||!array(p.recent)||p.recent.length>12||!array(p.memories)||p.memories.length>24||!object(p.peerAt)||!Number.isFinite(p.lastSocial)||!Number.isInteger(p.decisions))return false;}
 if(s.knowledge!==undefined&&s.knowledge!==null){const k=s.knowledge;if(!object(k)||k.version!==1||!object(k.facts)||!object(k.byKey)||!object(k.actors)||!object(k.migration)||!array(k.messages)||!Number.isInteger(k.nextFact)||k.nextFact<1||!Number.isInteger(k.nextMessage)||k.nextMessage<1)return false;for(const [id,f] of Object.entries(k.facts))if(!object(f)||f.id!==id||typeof f.sourceId!=='string'||typeof f.text!=='string'||!Number.isFinite(f.confidence)||f.confidence<0||f.confidence>1)return false;for(const a of Object.values(k.actors)){if(!object(a)||!object(a.entries))return false;for(const [id,e] of Object.entries(a.entries))if(!k.facts[id]||!object(e)||e.sourceId!==k.facts[id].sourceId||!Number.isFinite(e.acquiredAt)||e.acquiredAt<0||e.acquiredAt>s.tick)return false;}for(const m of k.messages)if(!object(m)||!k.facts[m.factId]||!['pending','delivered'].includes(m.status)||typeof m.from!=='string'||typeof m.to!=='string')return false;}

 if(s.calendar!==undefined&&s.calendar!==null){const c=s.calendar;if(!object(c)||c.version!==1||c.mode!=='wall'||typeof c.timeZone!=='string'||!Number.isFinite(c.wallCursor)||!Number.isFinite(c.lastSeen)||!Number.isFinite(c.displayMs)||!Number.isFinite(c.carry)||c.carry<0||c.carry>=60000||!object(c.occurrences)||!object(c.visitedWeeks)||!array(c.pending)||!array(c.corrections)||!object(c.recovery)||!Number.isFinite(c.maxCatchupMs)||c.maxCatchupMs<1||c.maxCatchupMs>604800000)return false;try{new Intl.DateTimeFormat('en',{timeZone:c.timeZone}).format(0);}catch{return false;}}
 if(s.unifiedWorld!==undefined&&s.unifiedWorld!==null){const w=s.unifiedWorld;if(!object(w)||w.version!==1||!object(w.canon)||Object.values(w.canon).some(x=>typeof x!=='string'||x.length>6000)||!array(w.archives)||!object(w.items)||!object(w.preferences)||!object(w.military)||!object(w.organisms)||!object(w.infections)||!Number.isFinite(w.military.reservePower)||w.military.reservePower<0||!array(w.military.visited)||!object(w.military.doors)||!object(w.seen))return false;for(const o of Object.values(w.organisms))if(!object(o)||typeof o.id!=='string'||!['adult','egg','spent egg','juvenile'].includes(o.stage)||typeof o.dormant!=='boolean'||o.behavior&&(!object(o.behavior)||o.behavior.version!==1||!['health','energy','stamina'].every(k=>Number.isFinite(o.behavior[k])&&o.behavior[k]>=0&&o.behavior[k]<=100)||!array(o.behavior.trace)||o.behavior.trace.length>64))return false;}

 if(s.anthology!==undefined){const a=s.anthology;if(!object(a)||a.version!==1||!array(a.arcs)||!object(a.seen)||!array(a.traditions)||!object(a.config)||!Number.isFinite(a.config.frequency)||a.config.frequency<0||a.config.frequency>3||!finiteMap(a.config.weights)||a.arcs.some(r=>!object(r)||typeof r.id!=='string'||!array(r.sources)||!array(r.history)||!Number.isFinite(r.started)||!Number.isFinite(r.progress)))return false;}
 const domains=['entities','experiences','emergencyOps','chronicles'],modern=requireModern||domains.some(k=>s[k]!==undefined);
 if(!modern)return true;
 if(domains.some(k=>!object(s[k])||s[k].version!==1))return false;
 const e=s.entities,m=s.experiences,o=s.emergencyOps,c=s.chronicles;
 if(!object(e.registry)||!array(e.encounters)||!array(e.organizations)||!object(e.stats)||!array(m.records)||!object(m.seen)||!object(m.assessments)||!array(o.incidents)||!object(o.transport)||!Number.isFinite(o.transport.condition)||!object(o.stats)||!object(c.weeks)||!object(c.seen))return false;
 for(const [id,n] of Object.entries(e.registry))if(!object(n)||id!==n.id||typeof n.name!=='string'||typeof n.location!=='string'||!Number.isFinite(n.reputation)||!finiteMap(n.stock)||!finiteMap(n.initial)||!finiteMap(n.received)||!finiteMap(n.spent)||!array(n.crew)||!array(n.history))return false;
 for(const w of Object.values(c.weeks))if(!object(w)||!array(w.sourceIds)||!array(w.segments))return false;
 for(const r of m.records)if(!object(r)||typeof r.id!=='string'||typeof r.sourceId!=='string'||typeof r.person!=='string')return false;
 if(!object(s.navigation)||!object(s.navigation.position)||!Number.isFinite(s.navigation.position.x)||!Number.isFinite(s.navigation.position.y)||!['orbit','transit','drift'].includes(s.navigation.phase))return false;
 if(!object(s.universe?.systems)||!array(s.frontier?.jobs)||!array(s.logistics?.receipts)||!finiteMap(s.economy?.stock)||!finiteMap(s.economy?.feedstock))return false;
 return true;
}
const api={valid};if(typeof module==='object'&&module.exports){root.ICARUSDroneSchema=require('./drone-schema');root.ICARUSCharacterDesign=require('./character-design');root.ICARUSExpeditionSchema=require('./expedition-schema');module.exports=api;}else root.ICARUSWorldSchema=api;
})(globalThis);

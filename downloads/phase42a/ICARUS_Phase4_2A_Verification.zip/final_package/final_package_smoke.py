import sys,json,unittest,os
from pathlib import Path
source=Path('/workspace/work/munza69/ICARUS')
root=Path('/workspace/work/phase42a/final_extracted/ICARUS_Phase4_2A_Observation_Protocol_Lite')
sys.path.insert(0,str(source))
import test_observation_integration as m
for module in list(sys.modules.values()):
 if getattr(module,'__name__','').startswith('test_') and hasattr(module,'ROOT'): module.ROOT=root
names=[n for n in unittest.defaultTestLoader.getTestCaseNames(m.ObservationIntegration) if n.startswith('test_protocol_')]
suite=unittest.TestSuite(m.ObservationIntegration(n) for n in names)
r=unittest.TextTestRunner(verbosity=2).run(suite)
report={'passed':r.wasSuccessful(),'runtime_root':str(root),'source_commit':json.loads((root/'BUILD_MANIFEST.json').read_text())['source_commit'],'tests_run':r.testsRun,'cases':names,'failures':[{'test':str(t),'detail':d} for t,d in r.failures],'errors':[{'test':str(t),'detail':d} for t,d in r.errors],'note':'Additional focused tests against the exact final ZIP extraction, including final Home menu. No runtime patches.'}
Path('/workspace/work/phase42a/release/final_package_smoke.json').write_text(json.dumps(report,indent=2))
raise SystemExit(not r.wasSuccessful())

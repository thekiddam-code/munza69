"""Real-wall-calendar accelerated campaign: hourly real intervals, actual production simulation steps."""
import argparse,functools,hashlib,http.server,json,os,threading,time,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,default=1001);ap.add_argument('--days',type=int,default=30);ap.add_argument('--scenario',choices=['normal','compound','released_chamber'],default='normal');ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    r={'seed':args.seed,'scenario':args.scenario,'real_days':args.days,'start':'2026-10-28T00:00:00Z','zone':'America/Chicago','source_commit':__import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':'running','passed':False,'errors':[],'daily':[],'checkpoints':[],'initialization':'Fixed seed and explicit wall clock. Simulation uses production step+field controllers; per-step autosave disabled in deterministic test driver; save/reload checked explicitly.'};r['runtime_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'server.py',ROOT/'requirements.txt',ROOT/'config.json',ROOT/'Start_Remote_Deck.bat',*sorted((ROOT/'web').rglob('*'))] if p.is_file()};start=time.monotonic();server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT/'web')));threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as pw:
            b=pw.chromium.launch(executable_path=os.environ.get('ICARUS_CHROMIUM') or None);c=b.new_context();c.add_init_script('window.__icarusSeed='+str(args.seed));p=c.new_page();p.set_default_timeout(120000);p.on('pageerror',lambda e:r['errors'].append(str(e)));p.goto(f'http://127.0.0.1:{server.server_port}/icarus.html?icarus_soak=1');p.wait_for_function('!!window.__icarusSoak')
            if args.scenario!='normal':
                assert p.evaluate('__icarusSoak.save()')
                payload=p.evaluate('''scenario=>{const s=JSON.parse(localStorage.getItem('icarus-v02'));if(scenario==='compound'){s.equipment.B07.condition=10;s.equipment.C09.condition=32;s.equipment.C07.condition=45;ICARUSLife.hurt(s,s.crew[0],45,'explicit adverse initial injury',(k,m,people,data)=>ICARUSStory.record(s,k,m,people,{...data,fixture:true}));}else{const members=s.crew.slice(0,2);const m={id:'ADVERSE-CHAMBER',crew:members[0].name,members:members.map(p=>p.name),phase:'onsite',progress:0,kit:0,suits:2,cargo:{},conditions:{},onsiteMinutes:0,workRate:1};for(const p of members){p.expeditionAway='asteroid';p.expeditionId=m.id;p.route=[];}for(const [k,n] of Object.entries({food:2,water:4,oxygen:4}))ICARUSEconomy.moveToCargo(s,m.cargo,k,n);s.teamLog.suits-=2;s.remoteCore.missions.asteroid=m;s.remoteCore.director.registry.push({id:m.id,crew:m.crew,members:m.members,type:'survey',location:'asteroid',status:'active',created:s.tick,baseline:{surveyed:0,findings:0}});s.asteroidExploration.position=23;s.asteroidExploration.rooms[23].visited=true;s.unifiedWorld.organisms['XENO-INITIAL'].dormant=false;s.unifiedWorld.organisms['XENO-INITIAL'].sealed=false;s.unifiedWorld.military.doors[23]='open';}return {format:'ICARUS_SAVE',formatVersion:1,appVersion:'1.6.0-phase2',state:s,history:s.chronicle.records,historyComplete:true,ideas:[]};}''',args.scenario)
                encoded=json.dumps(payload).encode();r['scenario_payload_sha256']=hashlib.sha256(encoded).hexdigest();r['scenario_application']='Normal backup-import UI in isolated test context; explicit initial fixture, not a natural simulation event.'
                p.on('dialog',lambda d:d.accept());p.locator('#backupfile').set_input_files({'name':'explicit-adverse-initial-state.json','mimeType':'application/json','buffer':encoded});p.wait_for_function('''scenario=>{const s=__icarusSoak.snapshot();return scenario==='compound'?s.world.equipment.B07.condition===10&&s.crew[0].vitals.health===55:s.unifiedWorld.organisms['XENO-INITIAL'].sealed===false&&s.missions.asteroid?.id==='ADVERSE-CHAMBER';}''',arg=args.scenario);r['scenario_import_message']=p.locator('#backupmessage').inner_text()
                initial=p.evaluate('__icarusSoak.snapshot()');r['initial_state']={'tick':initial['tick'],'equipment':{k:initial['world']['equipment'][k]['condition'] for k in ['B07','C09','C07']},'crew0_health':initial['crew'][0]['vitals']['health'],'organism':initial['unifiedWorld']['organisms']['XENO-INITIAL'],'asteroid_mission':initial['missions']['asteroid'],'resource_audit':initial['resourceAudit']}
                assert not initial['resourceAudit']
                if args.scenario=='compound':assert r['initial_state']['crew0_health']==55 and r['initial_state']['equipment']=={'B07':10,'C09':32,'C07':45}
                else:assert r['initial_state']['organism']['sealed'] is False and r['initial_state']['organism']['dormant'] is False and r['initial_state']['asteroid_mission']['id']=='ADVERSE-CHAMBER' and sum(q.get('expeditionAway')=='asteroid' for q in initial['crew'])==2
                r['initial_state_validated']=True
            t=p.evaluate('()=>{const t=Date.parse("2026-10-28T00:00Z");__icarusSoak.realStart(t,"America/Chicago");return t;}')
            for day in range(1,args.days+1):
                for hour in range(1,25):p.evaluate('t=>__icarusSoak.realAdvance(t)',t+((day-1)*24+hour)*3600000)
                row=p.evaluate('__icarusSoak.daily()');cal=p.evaluate('__icarusSoak.snapshot().calendar');row['calendar']=cal;row['snapshot_bytes']=p.evaluate('JSON.stringify(__icarusSoak.snapshot()).length');r['daily'].append(row)
                if row['resource_errors'] or row['frontier_errors'] or row['chronicle_errors'] or row['knowledge_errors'] or row['creature_errors']:r['errors'].append('World audit failed day '+str(day))
                if len(row['crew'])+len(row['dead'])!=20:r['errors'].append('Crew identity count failed')
                if cal['recovery']['discardedMs'] or cal['recovery']['rollbackCount']:r['errors'].append('Uninterrupted campaign lost or rolled back wall time')
                assert p.evaluate('__icarusSoak.save()');row['storage']=p.evaluate('ICARUSSaveStore.stats()')
                if day in {7,30,args.days}:
                    before=p.evaluate('JSON.stringify(__icarusSoak.snapshot())');history=p.evaluate('ICARUSDurable.history().then(x=>JSON.stringify(x))');p.reload();p.wait_for_function('!!window.__icarusSoak');after=p.evaluate('JSON.stringify(__icarusSoak.snapshot())');same=before==after
                    if not same:r['errors'].append('Exact checkpoint reload mismatch day '+str(day))
                    snapshot=json.loads(after);r['checkpoints'].append({'real_day':day,'sim_days':row['tick']/1440,'episode':row['episode'],'exact_reload':same,'crew':len(row['crew']),'dead':len(row['dead']),'stories':row['anthology']['arcs'],'resources':row['stores'],'arrivals':row['arrivals'],'calendar_occurrences':list(cal['occurrences']),'organisms':snapshot['unifiedWorld']['organisms']})
                    raw=p.evaluate('localStorage.getItem("icarus-v02")')
                    (args.output/f'backup_{args.seed}_{day}.json').write_text('{"format":"ICARUS_SAVE","formatVersion":1,"appVersion":"1.6.0-phase2","state":'+raw+',"history":'+history+',"ideas":[]}')
                    # Save actual full in-memory snapshot and source history for independent audit, without pretending it is the serialized world envelope.
                    (args.output/f'snapshot_{args.seed}_{day}.json').write_text(after);(args.output/f'history_{args.seed}_{day}.json').write_text(history)
                (args.output/f'campaign_{args.seed}.json').write_text(json.dumps(r,indent=2));print(args.seed,'real day',day,'sim day',round(row['tick']/1440,3),'crew',len(row['crew']),'errors',r['errors'],flush=True)
                if r['errors']:break
            r['passed']=not r['errors'] and len(r['daily'])==args.days;r['status']='finished';b.close()
    except Exception as e:r['errors'].append(str(e));r['traceback']=traceback.format_exc();r['status']='failed'
    finally:server.shutdown();r['elapsed_seconds']=time.monotonic()-start;(args.output/f'campaign_{args.seed}.json').write_text(json.dumps(r,indent=2))
    return not r['passed']
if __name__=='__main__':raise SystemExit(main())

import sys,unittest,json
from pathlib import Path
sys.path.insert(0,'/workspace/work/munza69/ICARUS')
from test_personalities_integration import PersonalitiesIntegration as T
from test_personalities_clock import PersonalitiesClock as C
root=Path('/workspace/work/phase42b/zip_test/ICARUS_Phase4_2B_Living_Personalities_Lite')
for m in list(sys.modules.values()):
 if getattr(m,'__name__','').startswith('test_') and hasattr(m,'ROOT'):m.ROOT=root
original=T.page
T.page=lambda self:(setattr(self,'last_page',original(self)) or self.last_page)
original_test=T.test_phase42b_pixel_feed_does_not_show_an_unrelated_classic_room_counter
def overlay(self):
 original_test(self);self.last_page.locator('#camera-scene').screenshot(path='/workspace/work/phase42b/release/final_zip_pixel.png')
T.test_phase42b_pixel_feed_does_not_show_an_unrelated_classic_room_counter=overlay
names=['test_phase42b_cross_deck_journey_uses_one_cabin_and_camera_occupancy','test_phase42b_schematic_lift_matches_camera_and_focus_is_readonly','test_phase42b_pixel_feed_does_not_show_an_unrelated_classic_room_counter']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([*[T(n) for n in names],C('test_production_twenty_switch_pause_reload_and_unique_sources')]))
Path('/workspace/work/phase42b/release/final_zip_smoke.json').write_text(json.dumps({'passed':r.wasSuccessful(),'tests_run':r.testsRun,'source_commit':json.loads((root/'BUILD_MANIFEST.json').read_text())['source_commit'],'runtime_root':str(root),'failures':[{'test':str(t),'detail':d} for t,d in r.failures],'errors':[{'test':str(t),'detail':d} for t,d in r.errors],'scope':'Exact final extracted ZIP. Cross-deck camera/cabin, schematic occupancy, pixel/classic counter purity, production20x/pause/reload. External source harness; runtime unmodified.'},indent=2));raise SystemExit(not r.wasSuccessful())


# Optional Phase 4A verification evidence

Not the runtime installer; use the separate Lite ZIP. Includes actual reports, screenshots, deterministic campaign backups/history, test sources and authentic historical fixture exports plus v1.3 web source. None are the user's private live voyage. Native APK/physical TV/Windows/AV results are NOT included because they were not run.

See reports/REPRODUCE.md. Original harness paths identify the execution workspace: adjust them to your local extracted runtime, test_source, fixtures and browser. SOURCE must reference a checkout of the package manifest source commit for imported test helpers. Use fixtures/migrations/*.json as donors and fixtures/v13/web for the v1.3 compatibility fixture. Runtime_source hashes in reports identify the frozen implementation, while final Lite includes documentation-only updates. Verification manifest hashes every evidence file.

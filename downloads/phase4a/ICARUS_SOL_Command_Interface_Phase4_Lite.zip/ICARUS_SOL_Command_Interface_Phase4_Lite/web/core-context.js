/* Bounded local contexts, not a procedural planetary universe. Frozen legacy records remain readable. */
(function(root){'use strict';
function install(U,N){const oldInit=U.init,oldChoose=N.choose,oldScan=U.scan,oldPlan=N.plan;
 U.init=function(s){if(!root.ICARUSEdition?.core)return oldInit(s);if(!s.universe)s.universe={version:1,seed:U.hash(s.entropy?.seed||1,'icarus-universe'),systems:{'CORE':{id:'CORE',name:'Local encounter context',x:0,y:0,bodies:[{id:'HOME',systemId:'CORE',name:'ICARUS / established expedition context',type:'ship context',x:0,y:0,hazard:0,interest:0,deposits:{},initialDeposits:{},extracted:{},visited:true,surveyed:true,signalResolved:true}]}},scanned:{},visitedCount:1};
 const u=s.universe;if(!u.coreContext){const anchor=s.navigation?.position||{x:0,y:0},types=[['DEBRIS','Survey debris',.3,{ore:600,fuel:80}],['ICE','Local ice contact',.12,{waterIce:600}],['RELAY','Independent service relay',.05,{fuel:600,nutrients:200,ore:400}],['HULL','Silent derelict',.35,{ore:120,fuel:40}],['ECHO','Unresolved instrument echo',.08,{}]];u.coreContext={version:1,at:s.tick,frozenSystems:Object.keys(u.systems).length,anchor:{...anchor}};const sys={id:'CORE-LOCAL',x:anchor.x,y:anchor.y,name:'Observed local contacts',bodies:types.map(([key,name,hazard,deposits],i)=>({id:'LOCAL-'+key,systemId:'CORE-LOCAL',name,type:key==='HULL'?'derelict':key==='RELAY'?'rare installation':key==='DEBRIS'?'asteroid field':'local observation',x:anchor.x+(i+1)*.07,y:anchor.y+.04*(i%2),hazard,interest:.4,landingDistance:22,temperature:-70,biological:false,composition:'silicate',deposits:{...deposits},initialDeposits:{...deposits},extracted:{},resourceHints:Object.fromEntries(Object.keys(deposits).map(k=>[k,true])),surveyed:false,visited:false,signalResolved:true,distress:false}))};u.systems[sys.id]=sys;}
 return u;};
 U.scan=function(s,x,y){if(!root.ICARUSEdition?.core)return oldScan(s,x,y);U.init(s);s.universe.lastScan=s.tick;return [];};
 N.plan=function(s,id,env,override=false){if(root.ICARUSEdition?.core&&id!=='HOME'&&!id.startsWith('LOCAL-')){s.navigation.lastDecision={at:s.tick,reason:'Legacy destination retained as history; outside the core local operating context',requested:id};return {ok:false,reason:s.navigation.lastDecision.reason};}return oldPlan(s,id,env,override);};
 N.choose=function(s,env){
  if(!root.ICARUSEdition?.core)return oldChoose(s,env);
  const n=s.navigation,need=env.logistics.needs(s),fuel=s.economy.feedstock.fuel,transport=s.emergencyOps?.transport;
  if(transport&&(transport.unrecovered||transport.condition<65)){n.lastDecision={at:s.tick,reason:'Hold: no return-capable transport for local field objectives'};return null;}
  const jobs=s.frontier?.jobs||[],failed=(d,type)=>jobs.filter(j=>j.destination===d.id&&j.type===type&&j.status==='failed').length>=2;
  const value=d=>{
   const supply=Object.entries(need).some(([k,v])=>v>1&&(d.deposits[k]||0)>0&&!failed(d,'extract_'+k));
   const recovery=Object.values(d.cache||{}).some(v=>v>0)&&!failed(d,'recovery');
   const distress=d.distress&&!d.signalResolved&&!failed(d,'distress');
   return supply?100:recovery?85:distress?75:!d.surveyed&&!failed(d,'survey')?10:0;
  };
  const target=U.bodies(s).filter(d=>d.id.startsWith('LOCAL-')&&d.id!==n.current&&value(d)>0)
   .filter(d=>N.distance(n.position,d)*5+8<=fuel)
   .sort((a,b)=>value(b)-value(a)||N.distance(n.position,a)-N.distance(n.position,b))[0]||null;
  if(!target)n.lastDecision={at:s.tick,reason:'Hold: no feasible local objective within fuel reserve and recorded attempt limits'};
  return target;
 };
}
const api={install};if(typeof module==='object'&&module.exports)module.exports=api;else{root.ICARUSCoreContext=api;install(root.ICARUSUniverse,root.ICARUSNavigation);}
})(globalThis);

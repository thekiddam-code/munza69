ICARUS Phase4.3 operational verification evidence. All worlds/backups here are ISOLATED FICTIONAL TEST WORLDS, not your personal voyage. NEVER restore them over your voyage. Back up your own game before installing Lite.

Runtime freeze13ab447; package source790d994. Main/legacy501 executions plus one portable archival fixture rerun and eight extracted-ZIP smoke executions passed. Full test names, errors, source/hash and campaign data are retained.

accepted/ contains final results, bounded-source audits, actual elapsed watch and labeled visual fixtures. campaigns/ contains corrected actual7-real/25-ship-day normal and explicitly damaged/injured campaigns plus the original-seed2-real/40-ship-day recovery replay. Source/private-history, conservation, operations, identity and exact reload audits passed. Survival alone is not the acceptance measure.

rejected_candidate_127bda0/ preserves the real recovery-deadlock failure (20 deaths by tick44160). Its original driver passed state invariants but that outcome was rejected, investigated and corrected. development_diagnostics/ is an UNFROZEN mixed development browser run with one30-second reload timeout, not final acceptance. Final immutable78-case core run passed every case under unchanged assertions/timeouts.

Visual examples are explicit technical fixtures, not natural campaign incidents or recorded footage. The elapsed watch used actual time without soak hooks or injected needs/incidents. Desktop/TV I/O is stubbed and phones/tablets emulated. Physical Windows/Android/TV, native APK rebuild, LAN/Tailscale and antivirus tests were not run.

Reproduce with the full source from the development branch and verify_operations.py --suite browser|remote|clock|legacy|focused --runtime PATH_TO_LITE --report output.json. For archived migration cases pass --v13-web PATH_TO_EVIDENCE/fixtures/v13_web --phase41-backup PATH_TO_EVIDENCE/fixtures/phase41_backup.json --phase4-backup PATH_TO_EVIDENCE/fixtures/phase4_backup.json. Install development Playwright/Chromium separately. --chromium selects a browser. Cached v1.3 source commit ea984a8749c907fd373492283f085d769eebbd03; historical fixture hashes are in EVIDENCE_MANIFEST.json.

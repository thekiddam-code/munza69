import os,sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/work/munza69/ICARUS')
import test_operations_integration as m
root=Path('/workspace/work/phase43/corrected_runtime')
for x in list(sys.modules.values()):
 if getattr(x,'__name__','').startswith('test_') and hasattr(x,'ROOT'):x.ROOT=root
T=m.OperationsIntegration;T.setUpClass();t=T();t.setUp();out=Path('/workspace/work/phase43/accepted/visual_examples');out.mkdir(parents=True,exist_ok=True)
r={'source_commit':json.loads((root/'BUILD_MANIFEST.json').read_text())['source_commit'],'fixture':'Explicit generator wear at64%; source-backed engineer chooses, travels, collects actual tools/parts and works. Separate cargo0g loose-object fixture. These are technical examples, not natural campaign events.'}
try:
 p=t.page();t.configure(p,"s.remoteCore.autonomyEnabled=false;s.shipSystems.components['GRAVITY-CORE'].health=64;for(const q of s.crew.filter(q=>q.job==='Engineer')){q.taskMinutes=0;q.energy=95;q.emergencyId=null;q.maintenanceRoom=null;}")
 for i in range(420):
  t.advance(p,1);s=t.snap(p);o=s['world']['maintenance']['systemOrders'].get('GRAVITY-CORE')
  if o and o['phase']=='repairing' and o['progress']>0:
   q=next((q for q in s['crew'] if q.get('systemAssignment')=='GRAVITY-CORE' and q['room']=='C07' and not q['route'] and q.get('interaction')=='working'),None)
   if q:
    t.operations(p);p.locator('.obs-select').select_option('C07');p.wait_for_timeout(300);p.locator('#camera-scene').screenshot(path=str(out/'actual_engineering_fixture.png'));r['repair']={'tick':s['tick'],'engineer':q['name'],'order':o,'component':s['shipSystems']['components']['GRAVITY-CORE']};break
 assert 'repair' in r
 p=t.page();t.configure(p,"s.remoteCore.autonomyEnabled=false;const q=s.crew[0];q.room=q.target='C03';q.route=[];q.nav=null;q.goal=q.task='Resting';q.taskMinutes=90;q.maintenanceRoom=null;q.systemAssignment=null;s.shipSystems.zones.cargo.targetG=0;s.physicalWorld.rooms.C03.objects={sample:{name:'sample container',discovered:true,condition:100,massKg:8}};");t.advance(p,15);s=t.snap(p);assert s['shipSystems']['zones']['cargo']['g']==0;assert s['crew'][0]['room']=='C03';assert s['world']['physicalWorld']['rooms']['C03']['objects']['sample']['gravityMotion']['height']>0;t.operations(p);p.locator('.obs-select').select_option('C03');p.wait_for_timeout(300);p.locator('#camera-scene').screenshot(path=str(out/'zero_g_fixture.png'));r['zero_g']=p.evaluate('__icarusSoak.observation().rooms.find(r=>r.id==="C03")');assert any(x['state']=='float' for x in r['zero_g']['actors']);t.deck(p,'ship','systems');p.locator('.systems-zone').select_option('cargo');p.locator('.engineering-systems').screenshot(path=str(out/'engineering_controls.png'));r['errors']=t.errors;r['passed']=not t.errors
finally:
 (out/'examples.json').write_text(json.dumps(r,indent=2));t.errors=[];t.tearDown();T.tearDownClass()

"""Summarize measured final artifacts; reject incomplete/superseded campaigns."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,math
BASE=Path(__file__).resolve().parent;V=Path('/workspace/work/phase2_accepted_validation');PKG=Path('/workspace/work/phase2_accepted_package');PROJECT=Path('/workspace/work/munza69/ICARUS')
manifest=json.loads((V/'tested/ICARUS_Living_World_Phase2_Lite/BUILD_MANIFEST.json').read_text());source=manifest['source_commit'];runtime=manifest['runtime_files'];summary={'source_commit':source,'runtime_files':runtime,'tests':{},'campaigns':[],'not_run':['Native Windows BAT launcher and actual PyAutoGUI desktop/game input (Linux environment; input stubbed).','Physical Android phone, Wi-Fi interruptions and Samsung TV hardware/TLS (mobile emulation and TV socket stub used).','Firefox/Safari, hostile concurrent browser writers, exhaustive fuzzing/penetration and transitive dependency audit.','Antivirus engine scan (clamscan/Windows Defender unavailable); no protection was disabled or bypassed.','180/365-day Phase 2 full-world campaigns; final tested durations are stated individually.','The user\'s live Windows browser profile was not accessed; migration uses a real historical Phase 1 Lite campaign backup.']}
for name,h in runtime.items():assert hashlib.sha256((PROJECT/name).read_bytes()).hexdigest()==h,name
u=(V/'reports/unit.txt').read_text();unit={k:int(re.search(r'ℹ '+k+r' (\d+)',u).group(1)) for k in ['tests','pass','fail','skipped']};assert unit=={'tests':217,'pass':217,'fail':0,'skipped':0};summary['tests']['node']=unit
for name,count in [('living_world',46),('stability',30),('compatibility',44),('production',2),('bridge',3)]:
 r=json.loads((V/'reports'/f'{name}.json').read_text());assert r['passed'] and r['tests_run']==count and r['source_commit']==source,name;summary['tests'][name]={'passed':True,'tests_run':count,'runtime_root':r['runtime_root'],'source_commit':source}
for name in ['runtime_identity','syntax_dependencies','mobile_functional','phase1_backup','phase2_backup']:
 r=json.loads((V/'reports'/f'{name}.json').read_text());assert r['passed'],name;summary['tests'][name]=r
names={'Frank Morrow','Mara Chen','Dr. Voss','Derek Cole','Linda Park','Elena Ruiz','Jules Mercer','Nadia Kline','Owen Briggs','Priya Shah','Tomas Vale','Rhea Ortiz','Milo Grant','Sana Okafor','Iris Bell','Caleb Stone','Yara Finch','Theo Moss','June Adler','Ari Novak'}
for dirname in ['normal_1001','normal_4807','compound_1001','chamber_4807']:
 p=BASE/'campaigns'/dirname;r=json.loads(next(p.glob('campaign*.json')).read_text());assert r['passed'] and r['status']=='finished' and not r['errors'] and len(r['daily'])==r['real_days'],dirname;assert r['source_commit']==source or r.get('runtime_sha256')==runtime
 if r['scenario']!='normal':assert r.get('initial_state_validated') is True
 for d in r['daily']:
  assert not any(d[k] for k in ['resource_errors','frontier_errors','chronicle_errors','knowledge_errors','creature_errors'])
  assert {q['name'] for q in d['crew']}|set(d['dead'])==names;assert len(d['crew'])+len(d['dead'])==20
  assert all(math.isfinite(q[k]) and q[k]>=0 for q in d['crew'] for k in ['health','fatigue','morale','energy'])
  assert d['calendar']['recovery']['discardedMs']==0 and d['calendar']['recovery']['rollbackCount']==0
 assert all(c['exact_reload'] for c in r['checkpoints'])
 b=json.loads((p/f"backup_{r['seed']}_{r['real_days']}.json").read_text());s=b['state'];history=b['history'];ids={e['id'] for e in history};assert len(ids)==len(history)
 private={e['id'] for e in history if e.get('data',{}).get('privateKnowledge')};public={i for w in s['chronicles']['weeks'].values() for i in w['sourceIds']};assert not (private&public)
 assert public<=ids
 for f in s['knowledge']['facts'].values():assert f['sourceId'] in ids or f['sourceId'].startswith('LEGACY-CHART:')
 for actor in s['knowledge']['actors'].values():
  for fid,e in actor['entries'].items():assert fid in s['knowledge']['facts'] and e['sourceId']==s['knowledge']['facts'][fid]['sourceId'] and e['acquiredAt']<=s['tick']
 # Archived actual sources and chart observations may be retained beyond live 4000-event window.
 for a in s['unifiedWorld']['archives']:assert a['sourceId'] in ids
 for q in s['crew']:
  for name,entry in q.get('bereavements',{}).items():assert entry['sourceId'] in ids and any(s['knowledge']['facts'][f]['sourceId']==entry['sourceId'] for f in s['knowledge']['actors'][q['name']]['entries'])
 if r['scenario']=='normal':assert s['navigation']['arrivals']>0,'Stable but motionless voyage rejected'
 sc=s['remoteCore']['director']['science'];jobs=s['remoteCore']['director']['registry'];ledger=list(s['economy']['ledger'].values());last=r['daily'][-1]
 item={'profile':dirname,'seed':r['seed'],'scenario':r['scenario'],'source_commit':r['source_commit'],'runtime_source_commit':source,'initial_state_validated':r.get('initial_state_validated'),'initial_state':r.get('initial_state'),'scenario_application':r.get('scenario_application'),'real_days':r['real_days'],'sim_days':last['tick']/1440,'ticks':last['tick'],'episodes':last['episode'],'crew_alive':len(s['crew']),'deaths':len(s['living']['deceased']),'death_causes':[{'name':d['name'],'cause':d['cause']} for d in s['living']['deceased']],'daily_sample_min_health':min(q['health'] for d in r['daily'] for q in d['crew']) if any(d['crew'] for d in r['daily']) else None,'arrivals':s['navigation']['arrivals'],'fuel_used':s['navigation']['fuelUsed'],'field_missions':len(jobs),'field_statuses':dict(Counter(j['status'] for j in jobs)),'field_reasons':dict(Counter(j.get('completionReason','not finished') for j in jobs)),'staging_failures':sum(j.get('completionReason')=='staging_access' for j in jobs),'frontier_jobs':len(s['frontier']['jobs']),'frontier_types':dict(Counter(j['type'] for j in s['frontier']['jobs'])),'science_cases':len(sc['cases']),'retained_experiments':len(sc['experiments']),'retained_experiment_statuses':dict(Counter(e['status'] for e in sc['experiments'])),'confirmed_conclusions':sum(c.get('status')=='confirmed' for c in sc.get('conclusions',[])),'knowledge':last['knowledge'],'biology':last['biology'],'creature_attack_events':sum(e['kind']=='encounter' and 'organismId' in e.get('data',{}) and e['data'].get('encounter') is True and not e['data'].get('knowledgeDelivery') for e in history),'recorded_event_kinds':dict(Counter(e['kind'] for e in history)),'history_records':len(history),'private_records':len(private),'resource_final':last['stores'],'acquired':last['acquired'],'ledger_rows':len(ledger),'ledger_kinds':dict(Counter(e['kind'] for e in ledger)),'resource_sources':[{k:e[k] for k in ['kind','key','source','amount','count']} for e in ledger if e['kind'] in ['produce','recover','credit','loss']],'primary_cache_first_bytes':r['daily'][0]['storage']['primary_bytes'],'primary_cache_final_bytes':last['storage']['primary_bytes'],'snapshot_final_bytes':last['snapshot_bytes'],'exact_reload_checkpoints':r['checkpoints'],'elapsed_seconds':r['elapsed_seconds'],'audits_passed':True}
 summary['campaigns'].append(item)
summary['passed']=True;(BASE/'accepted_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'passed':True,'source_commit':source,'campaigns':[(r['profile'],r['sim_days'],r['arrivals']) for r in summary['campaigns']]},indent=2))

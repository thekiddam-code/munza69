import sys
from pathlib import Path
base=Path(__file__).resolve().parent;sys.path.insert(0,'/workspace/work/munza69/ICARUS')
import verify_frontier_backup
verify_frontier_backup.ROOT=base/'tested/ICARUS_Living_World_Phase2_Lite'
raise SystemExit(verify_frontier_backup.main())

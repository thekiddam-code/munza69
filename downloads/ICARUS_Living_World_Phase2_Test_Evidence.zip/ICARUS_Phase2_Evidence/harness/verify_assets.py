from pathlib import Path
from html.parser import HTMLParser
import ast,hashlib,json,subprocess,tempfile
base=Path(__file__).resolve().parent;root=base/'tested/ICARUS_Living_World_Phase2_Lite';m=json.loads((root/'BUILD_MANIFEST.json').read_text());checks=[]
for name,digest in m['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
class Scripts(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.parts=[];self.inline=[];self.refs=[]
 def handle_starttag(self,t,a):
  if t=='script':
   d=dict(a);self.active='src' not in d;self.parts=[]
   if 'src' in d:self.refs.append(d['src'])
 def handle_data(self,d):
  if self.active:self.parts.append(d)
 def handle_endtag(self,t):
  if t=='script' and self.active:self.inline.append(''.join(self.parts));self.active=False
with tempfile.TemporaryDirectory() as td:
 for p in sorted((root/'web').rglob('*.js')):subprocess.run(['node','--check',str(p)],check=True,capture_output=True);checks.append(str(p.relative_to(root)))
 for p in sorted((root/'web').glob('*.html')):
  parser=Scripts();parser.feed(p.read_text())
  for src in parser.refs:assert not src.startswith(('http:','https:','//'));assert (p.parent/src).is_file(),src
  for i,code in enumerate(parser.inline):
   q=Path(td)/'inline.js';q.write_text(code);subprocess.run(['node','--check',str(q)],check=True,capture_output=True);checks.append(str(p.relative_to(root))+':inline:'+str(i))
 ast.parse((root/'server.py').read_text());checks.append('server.py')
(base/'reports/syntax_dependencies.json').write_text(json.dumps({'passed':True,'source_commit':m['source_commit'],'verified_source_files':len(m['files']),'checks':checks,'script_dependencies_present_and_local':True},indent=2))
